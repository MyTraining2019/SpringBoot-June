package org.cap.model;

public class Employee {
	
	private int empId;
	private String firstName;
	private String lastName;
	
	private Department department;

	
	public Employee(){
		
	}
	
	
	public Employee(int empId, String firstName, String lastName, Department department) {
		super();
		System.out.println("Constructor Invoked");
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", department="
				+ department + "]";
	}
	
	

}
